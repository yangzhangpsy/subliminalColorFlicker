clear all;

exp1acc = [33.89 	37.78 
           34.44 	37.22 
           33.89 	30.00 
           36.67 	33.33 
           31.67 	35.00 
           30.56 	29.44 
           34.44 	31.67 
           31.11 	32.22 
           35.56 	35.00 
           35.56 	34.44 
           33.33 	35.00 
           33.33 	32.22 
           35.00 	31.11 
           32.78 	27.22 
           32.22 	31.67 
           31.67 	36.67 ];


exp2acc = [39.17 	35.83 
           40.83 	35.00 
           30.83 	35.83 
           31.67 	37.50 
           36.67 	33.33 
           31.67 	33.33 
           38.33 	30.83 
           33.33 	36.67 
           26.67 	39.16 
           40.00 	34.17 
           36.67 	35.00 
           25.00 	28.33 
           31.67 	32.50 
           32.50 	32.67 ];

exp3acc = [32.78 
27.22 
34.44 
39.44 
32.22 
31.11 
33.33 
32.22 
34.44 
34.44 
30.00 
33.89 
32.78 
36.67 ];

% exp 1 acc (exp1a in the paper)
[exp1_dprimeOfMean,exp1_acc_qSqure,exp1_dprimes] = mAFC2dprime(exp1acc,3);
%  exp 2 acc (exp1b in the paper)
[exp2_dprimeOfMean,exp2_acc_qSqure,exp2_dprimes] = mAFC2dprime(exp2acc,3);
% exp 1 and 2  (exp1ab in the paper)
[exp12_dprimeOfMean,exp12_acc_qSqure,exp12_dprimes] = mAFC2dprime([exp1acc;exp2acc],3);
% exp 3
[exp3_dprimeOfMean,exp3_acc_qSqure,exp3_dprimes] = mAFC2dprime(exp3acc,3);

% dprime 95 CIs
[~,~,exp1_dp_ci] = ttest(exp1_dprimes);
[~,~,exp2_dp_ci] = ttest(exp2_dprimes);
[~,~,exp3_dp_ci] = ttest(exp3_dprimes);
[~,~,exp12_dp_ci] = ttest([exp1_dprimes,exp2_dprimes]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% experiment 1 (exp1a in the paper)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load(fullfile(pwd,'excludedAll','classficationMatrix_Exp1.mat'));

exp1 = classficationCueing(classficationMatrix_Exp_1);

exp1isi50 = exp1(exp1(:,2)==1,:);
exp1_qSquare_50 = (std(exp1isi50(:,end)))^2;
[~,exp1_isi50_p,exp1_isi50_ci,exp1_isi50_stats] = ttest(exp1_dprimes',exp1isi50(:,end));
[~,~,exp1_isi50_main_ci] = ttest(exp1isi50(:,end));

exp1_isi50_dpData = [exp1_dprimes',exp1isi50(:,end)];

exp1isi700 = exp1(exp1(:,2)==3,:);
exp1_qSquare_700 = (std(exp1isi700(:,end)))^2;
[~,exp1_isi700_p,exp1_isi700_ci,exp1_isi700_stats] = ttest(exp1_dprimes',exp1isi700(:,end));
[~,~,exp1_isi700_main_ci] = ttest(exp1isi700(:,end));

exp1_isi700_dpData = [exp1_dprimes',exp1isi700(:,end)];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% experiment 2  (exp1b in the paper)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load(fullfile(pwd,'excludedAll','classficationMatrix_Exp2.mat'));
exp2 = classficationCueing(classficationMatrix_Exp_2);


exp2(:,1) = exp2(:,1) + 100;% change subjectnum to add 100
exp2isi50 = exp2(exp2(:,2)==1,:);
exp2_qSquare_50 = (std(exp2isi50(:,end)))^2;

[~,exp2_isi50_p,exp2_isi50_ci,exp2_isi50_stats] = ttest(exp2_dprimes',exp2isi50(:,end));
[~,~,exp2_isi50_main_ci] = ttest(exp2isi50(:,end));

exp2_isi50_dpData = [exp2_dprimes',exp2isi50(:,end)];


exp2isi500 = exp2(exp2(:,2)==3,:);
exp2_qSquare_500 = (std(exp2isi500(:,end)))^2;

[~,exp2_isi500_p,exp2_isi500_ci,exp2_isi500_stats] = ttest(exp2_dprimes',exp2isi500(:,end));
[~,~,exp2_isi500_main_ci] = ttest(exp2isi500(:,end));

exp2_isi500_dpData = [exp2_dprimes',exp2isi500(:,end)];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% experiment 1 and 2 (exp 1ab in the paper)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


exp12 = [exp1;exp2];
%%%%%%%%%%%%%%%%%%%%%
% isi 1: 50 ms
%%%%%%%%%%%%%%%%%%%%%%
isi50 = exp12(exp12(:,2)==1,:);

exp12_qSquare_50 = (std(isi50(:,end)))^2;

[~,exp12_isi50_p,exp12_isi50_ci,exp12_isi50_stats] = ttest([exp1_dprimes,exp2_dprimes]',isi50(:,end));
[~,~,exp12_isi50_main_ci] = ttest(isi50(:,end));

exp12_isi50_dpData = [[exp1_dprimes,exp2_dprimes]',isi50(:,end)];
%%%%%%%%%%%%%%%%%%%%%%%
% isi 3 :500 ms
%%%%%%%%%%%%%%%%%%%%%%%%

isi500 = exp12(exp12(:,2)==3,:);

exp12_qSquare_500 = (std(isi500(:,end)))^2;
[~,exp12_isi500_p,exp12_isi500_ci,exp12_isi500_stats] = ttest([exp1_dprimes,exp2_dprimes]',isi500(:,end));
[~,~,exp12_isi500_main_ci] = ttest(isi500(:,end));
exp12_isi500_dpData = [[exp1_dprimes,exp2_dprimes]',isi500(:,end)];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% experiment 3 (exp2 in the paper)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% isi 50 ms
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load(fullfile(pwd,'excludedAll','classficationMatrix_Exp3.mat'));

exp3 = classficationCueing(classficationMatrix_Exp3);

exp3isi50 = exp3(exp3(:,2)==1,:);

exp3_qSquare_50 = (std(exp3isi50(:,end)))^2;

[~,exp3_isi50_p,exp3_isi50_ci,exp3_isi50_stats] = ttest(exp3_dprimes',exp3isi50(:,end));
[~,~,exp3_isi50_main_ci] = ttest(exp3isi50(:,end));
%%%%%%%%%%%%%%%%%%%%%%%%%%
% isi 500ms
%%%%%%%%%%%%%%%%%%%%%%%%%%
exp3isi500 = exp3(exp3(:,2)==2,:);

exp3_qSquare_500 = (std(exp3isi500(:,end)))^2;


[~,exp3_isi500_p,exp3_isi500_ci,exp3_isi500_stats] = ttest(exp3_dprimes',exp3isi500(:,end));
[~,~,exp3_isi500_main_ci] = ttest(exp3isi500(:,end));





