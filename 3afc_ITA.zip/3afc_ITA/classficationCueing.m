function outData = classficationCueing(data,labelMethods)
% data:
% col 1: subject num
% col 2: ISI
% col 3: cueing (1 and 0 for cued and uncued repsectively)
% col 4: rt


if ~exist('labelMethods','var')
    labelMethods = 1 ;% 1 for cued
end 

subCons = unique(data(:,[1,2]),'rows');

outData = zeros(size(subCons,1),5);

for iSubCon=1:size(subCons,1)

	cFilter = ismember(data(:,[1,2]),subCons(iSubCon,:),'rows');

	cData = data(cFilter,:);

	[ph,pfa] = subConClass(cData,labelMethods);


	% outData(iSubCon,:) = [subCons(iSubCon,:),ph,pfa,dprime(ph,pfa)];
	outData(iSubCon,:) = [subCons(iSubCon,:),ph,pfa,dprime_mAFC(ph,2)];
end 





end 


function [ph,pfa] = subConClass(conData,labelMethods)

		cM = median(conData(:,4));
        
        if labelMethods
            classCueing = conData(:,4) <= cM;
        else
            classCueing = conData(:,4) > cM;
        end 

		ph = mean(classCueing==conData(:,3));

		pfa = 1 - ph;

end 