function [dprimeOfMean,qSqure,dprimes] = mAFC2dprime(acc,m)

if mean(acc(:))>1

	scale = 100;
else
	scale = 1;
end


meanAcc = mean(acc,2)/scale;

for i=1:numel(meanAcc)
	dprimes(i) = dprime_mAFC(meanAcc(i),m);
end 

qSqure = (std(dprimes))^2;

dprimeOfMean = dprime_mAFC(mean(meanAcc),m);
% dprimeOfMean = mean(dprimes);

end 