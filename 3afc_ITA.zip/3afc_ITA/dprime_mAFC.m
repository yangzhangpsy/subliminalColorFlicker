function dprime = dprime_mAFC(Pc, m)
% argin:
% Pc a double: probability correct choice (unbiased ovserver) should be in the range of 0 to 1
% m  an integer: number of choices
% adopted by Yang Zhang from dprime.mAFC.R 
% Soochow university


if Pc < 0 || Pc > 1
    error('Pc should be in the range of 0 to 1');
end 

if rem(m,1) ~= 0
    error('m should be a integer');
end 

myFun = @(x,Pc,m) dpFun(x,Pc,m);

fun = @(x) myFun(x,Pc,m);

dprime = fzero(fun,[-10, 10]);
end


function y = dpFun(dp,Pc,m)
fun = @(x,dp) normpdf(x-dp).*normcdf(x).^(m-1);

y = Pc - integral(@(x)fun(x,dp),-inf,inf);
end




